<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', '' );


/** Имя пользователя MySQL */
define( 'DB_USER', '' );


/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );


/** Имя сервера MySQL */
define( 'DB_HOST', '' );


/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );


/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'a|APt)D!N-UiU{tG|i[9vedN}GV:0 GRJ!#_Lyd.|:2X$}h3RocblsR!o~$7IXGF' );

define( 'SECURE_AUTH_KEY',  '^:tMi@Y%^FV(Si#0:/b32`NN5WV.3;0bf4>sEa!$$q*e0>`u(<NQ+wXe`2~K7v&V' );

define( 'LOGGED_IN_KEY',    'Ta}ac0!LIrxjX#{Pn0fW;$0#Wd`m&PX<eah4s7-%X:kr=EH:GIo&PIwmE3a|B6xw' );

define( 'NONCE_KEY',        '7+ng@+^oVda;36>%3<&wDy`=VmNprUd P_{#6/`v!ZFIe~.ML`pJ:NimsnV0VkTy' );

define( 'AUTH_SALT',        'BbT?d^,#b@Uz?W3w3%,]]RVK4_jC*w3b>ifg5[z5G.ZaD0Oc<4Jjwjk0._I)oX=W' );

define( 'SECURE_AUTH_SALT', '_dqMCoUi||?-&|/V[IsBFnk7Z$%jK9iT@L5Ql70~T^Ud)/GG],7?:L6)9O@]X?Xi' );

define( 'LOGGED_IN_SALT',   'Yb3][?19WE8C`w_/oEts$fR2Jc}C[toXT99UTUnt<^-S~(XN:;1^5&uFE5ZB*o7~' );

define( 'NONCE_SALT',       'zoH ,=5[nqB.2_vS=BQ6R|^ptsGM8zCZcsy+nAejKAhqEvn<bcMExef}F<s8x(;w' );


/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';


/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
